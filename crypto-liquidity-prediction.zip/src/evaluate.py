# evaluate.py
import numpy as np
import pandas as pd
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from tensorflow.keras.models import load_model
import joblib
from data_loader import load_data
from preprocess import clean_missing_fill, remove_outliers_iqr, scale_features
from feature_engineer import generate_all_features
from utils import train_test_split_time_series, create_lstm_sequences
from config import SAVED_MODEL_PATH, MODEL_DIR, SCALER_FEATURES, TARGET_COLUMN, LOOKBACK

def evaluate_lstm():
    # Load data and process same as training
    df = load_data()
    df = clean_missing_fill(df)
    df = remove_outliers_iqr(df, cols=["Open","High","Low","Close","Volume"] )
    df = generate_all_features(df)
    feature_cols = SCALER_FEATURES + [c for c in df.columns if c.startswith("MA_") or c in ["Volatility","Pct_Volatility","Return","Liquidity_lag1"]]
    feature_cols = [c for c in feature_cols if c in df.columns]
    scaler = joblib.load(f"{MODEL_DIR}/scaler.joblib")
    df_scaled = df.copy()
    df_scaled[feature_cols] = scaler.transform(df[feature_cols])

    train, test = train_test_split_time_series(df_scaled, TARGET_COLUMN)
    X_test, y_test = create_lstm_sequences(test[feature_cols].values, test[TARGET_COLUMN].values, lookback=LOOKBACK)

    model = load_model(SAVED_MODEL_PATH)
    preds = model.predict(X_test).flatten()
    mse = mean_squared_error(y_test, preds)
    rmse = np.sqrt(mse)
    mae = mean_absolute_error(y_test, preds)
    r2 = r2_score(y_test, preds)
    print("LSTM Evaluation:")
    print(f"RMSE: {rmse:.6f}")
    print(f"MAE: {mae:.6f}")
    print(f"R2: {r2:.4f}")

def evaluate_rf():
    # Evaluate RF baseline
    df = load_data()
    df = clean_missing_fill(df)
    df = remove_outliers_iqr(df, cols=["Open","High","Low","Close","Volume"] )
    df = generate_all_features(df)
    feature_cols = SCALER_FEATURES + [c for c in df.columns if c.startswith("MA_") or c in ["Volatility","Pct_Volatility","Return","Liquidity_lag1"]]
    feature_cols = [c for c in feature_cols if c in df.columns]
    scaler = joblib.load(f"{MODEL_DIR}/scaler.joblib")
    df_scaled = df.copy()
    df_scaled[feature_cols] = scaler.transform(df[feature_cols])

    train, test = train_test_split_time_series(df_scaled, TARGET_COLUMN)
    # align to lookback: skip first LOOKBACK rows
    from config import LOOKBACK
    rf_train_X = train[feature_cols].values[LOOKBACK:]
    rf_train_y = train[TARGET_COLUMN].values[LOOKBACK:]
    rf_test_X = test[feature_cols].values[LOOKBACK:]
    rf_test_y = test[TARGET_COLUMN].values[LOOKBACK:]

    rf = joblib.load(f"{MODEL_DIR}/rf_model.joblib")
    preds = rf.predict(rf_test_X)
    mse = mean_squared_error(rf_test_y, preds)
    rmse = np.sqrt(mse)
    mae = mean_absolute_error(rf_test_y, preds)
    r2 = r2_score(rf_test_y, preds)
    print("RandomForest Evaluation:")
    print(f"RMSE: {rmse:.6f}")
    print(f"MAE: {mae:.6f}")
    print(f"R2: {r2:.4f}")

if __name__ == "__main__":
    print("Evaluating LSTM model...")
    evaluate_lstm()
    print("\nEvaluating RandomForest baseline...")
    evaluate_rf()
