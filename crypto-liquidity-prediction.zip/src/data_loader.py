# data_loader.py
import pandas as pd
from config import DATA_PATH

def load_data(path=DATA_PATH):
    """
    Load dataset CSV. Expected columns: Date, Open, High, Low, Close, Volume, MarketCap (if available)
    """
    df = pd.read_csv(path)
    # Standardize column names
    df.columns = [c.strip() for c in df.columns]
    # Ensure Date column
    if "Date" in df.columns:
        df["Date"] = pd.to_datetime(df["Date"])
        df = df.sort_values("Date").reset_index(drop=True)
    else:
        raise ValueError("Dataset must include 'Date' column.")
    return df

if __name__ == "__main__":
    df = load_data()
    print("Loaded data:", df.shape)
    print(df.head())
