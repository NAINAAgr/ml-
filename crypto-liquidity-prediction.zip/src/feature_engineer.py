# feature_engineer.py
import pandas as pd
import numpy as np

def add_moving_averages(df, col="Close", windows=[7, 30]):
    df = df.copy()
    for w in windows:
        df[f"MA_{w}"] = df[col].rolling(window=w, min_periods=1).mean()
    return df

def add_volatility(df):
    df = df.copy()
    df["Volatility"] = df["High"] - df["Low"]
    # Optionally add percent volatility
    df["Pct_Volatility"] = (df["Volatility"] / (df["Close"] + 1e-9)) * 100
    return df

def add_liquidity_ratio(df):
    df = df.copy()
    # A simple liquidity proxy: Volume / MarketCap (if MarketCap exists)
    if "MarketCap" in df.columns:
        df["Liquidity"] = df["Volume"] / (df["MarketCap"] + 1e-9)
    else:
        # fallback: normalized Volume (later scaled)
        df["Liquidity"] = df["Volume"]
    return df

def add_returns(df):
    df = df.copy()
    df["Return"] = df["Close"].pct_change().fillna(0)
    return df

def generate_all_features(df):
    df = df.copy()
    df = add_moving_averages(df, col="Close", windows=[7, 30])
    df = add_volatility(df)
    df = add_returns(df)
    df = add_liquidity_ratio(df)
    # lag features
    df["Liquidity_lag1"] = df["Liquidity"].shift(1).fillna(method="bfill")
    return df

if __name__ == "__main__":
    from data_loader import load_data
    df = load_data()
    df = generate_all_features(df)
    print(df.head())
