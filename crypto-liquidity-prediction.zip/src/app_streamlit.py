# app_streamlit.py
import streamlit as st
import pandas as pd
import numpy as np
import joblib
from tensorflow.keras.models import load_model
from data_loader import load_data
from preprocess import clean_missing_fill, remove_outliers_iqr
from feature_engineer import generate_all_features
from config import MODEL_DIR, SAVED_MODEL_PATH, SCALER_FEATURES, TARGET_COLUMN, LOOKBACK

st.set_page_config(page_title="Crypto Liquidity Predictor", layout="wide")

@st.cache_data
def load_models():
    scaler = joblib.load(f"{MODEL_DIR}/scaler.joblib")
    rf = joblib.load(f"{MODEL_DIR}/rf_model.joblib")
    lstm = load_model(SAVED_MODEL_PATH)
    return scaler, rf, lstm

st.title("Cryptocurrency Liquidity Predictor")
st.write("Upload a CSV with Date, Open, High, Low, Close, Volume, MarketCap (optional).")

uploaded = st.file_uploader("Upload CSV", type=["csv"])
scaler, rf_model, lstm_model = None, None, None

if uploaded is not None:
    df = pd.read_csv(uploaded)
    df.columns = [c.strip() for c in df.columns]
    df["Date"] = pd.to_datetime(df["Date"])
    df = df.sort_values("Date").reset_index(drop=True)
    st.write("Data sample:", df.head())

    df = clean_missing_fill(df)
    df = remove_outliers_iqr(df, cols=["Open","High","Low","Close","Volume"])
    df = generate_all_features(df)

    # load models & scaler
    scaler, rf_model, lstm_model = load_models()

    feature_cols = SCALER_FEATURES + [c for c in df.columns if c.startswith("MA_") or c in ["Volatility","Pct_Volatility","Return","Liquidity_lag1"]]
    feature_cols = [c for c in feature_cols if c in df.columns]

    df_scaled = df.copy()
    df_scaled[feature_cols] = scaler.transform(df[feature_cols])

    st.subheader("Last rows with features")
    cols_display = ["Date"] + feature_cols + ([TARGET_COLUMN] if TARGET_COLUMN in df_scaled.columns else [])
    st.dataframe(df_scaled.tail(10)[cols_display])

    # Predict with RF: use the last available row
    last_features = df_scaled[feature_cols].values[-1].reshape(1, -1)
    rf_pred = rf_model.predict(last_features)[0]
    st.metric("RandomForest Liquidity Prediction (last row)", f"{rf_pred:.6f}")

    # Predict with LSTM: prepare recent LOOKBACK window
    if len(df_scaled) >= LOOKBACK:
        X_seq = df_scaled[feature_cols].values[-LOOKBACK:].reshape(1, LOOKBACK, len(feature_cols))
        lstm_pred = float(lstm_model.predict(X_seq).flatten()[0])
        st.metric("LSTM Liquidity Prediction (next day)", f"{lstm_pred:.6f}")
    else:
        st.info(f"Need at least {LOOKBACK} rows to run LSTM prediction. Current rows: {len(df_scaled)}")
