# config.py
# Central config — change paths / params here.

DATA_PATH = "../data/crypto_data.csv"   # relative to src/
MODEL_DIR = "../models"
SAVED_MODEL_PATH = f"{MODEL_DIR}/saved_model.h5"

# Training params
TEST_SIZE = 0.2
RANDOM_STATE = 42
SCALER_FEATURES = ["Open", "High", "Low", "Close", "Volume", "MarketCap"]
TARGET_COLUMN = "Liquidity"  # engineered target
LOOKBACK = 30  # days window for LSTM
EPOCHS = 50
BATCH_SIZE = 32
