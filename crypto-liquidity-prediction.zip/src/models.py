# models.py
import os
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout
from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint
from sklearn.ensemble import RandomForestRegressor
from xgboost import XGBRegressor
from config import SAVED_MODEL_PATH, MODEL_DIR
import joblib

os.makedirs(MODEL_DIR, exist_ok=True)

def build_lstm(input_shape, neurons=64, dropout=0.2):
    model = Sequential()
    model.add(LSTM(neurons, input_shape=input_shape, return_sequences=True))
    model.add(Dropout(dropout))
    model.add(LSTM(neurons // 2))
    model.add(Dropout(dropout))
    model.add(Dense(1, activation="linear"))
    model.compile(optimizer="adam", loss="mse", metrics=["mae"])
    return model

def train_lstm(model, X_train, y_train, X_val, y_val, saved_path=SAVED_MODEL_PATH, epochs=50, batch_size=32):
    callbacks = [
        EarlyStopping(monitor="val_loss", patience=8, restore_best_weights=True),
        ModelCheckpoint(saved_path, monitor="val_loss", save_best_only=True, save_weights_only=False)
    ]
    history = model.fit(
        X_train, y_train,
        validation_data=(X_val, y_val),
        epochs=epochs,
        batch_size=batch_size,
        callbacks=callbacks,
        verbose=2
    )
    return history

def train_random_forest(X_train, y_train, n_estimators=100, random_state=42):
    rf = RandomForestRegressor(n_estimators=n_estimators, random_state=random_state, n_jobs=-1)
    rf.fit(X_train, y_train)
    return rf

def save_sklearn_model(model, path):
    joblib.dump(model, path)

def load_sklearn_model(path):
    return joblib.load(path)
