# utils.py
import os
import numpy as np
from sklearn.model_selection import train_test_split

from config import TEST_SIZE, RANDOM_STATE, LOOKBACK

def train_test_split_time_series(df, target_col, test_size=TEST_SIZE):
    """
    Splits by time: earlier rows for train, later for test.
    """
    n = len(df)
    split_idx = int(n * (1 - test_size))
    train = df.iloc[:split_idx].reset_index(drop=True)
    test = df.iloc[split_idx:].reset_index(drop=True)
    return train, test

def create_lstm_sequences(df_features, df_target, lookback=LOOKBACK):
    """
    Create sequences for LSTM: X shape (samples, lookback, features), y shape (samples,)
    df_features: numpy array (n_rows, n_features)
    df_target: numpy array (n_rows,)
    """
    X, y = [], []
    for i in range(len(df_features) - lookback):
        X.append(df_features[i:i+lookback])
        y.append(df_target[i+lookback])
    return np.array(X), np.array(y)
