# preprocess.py
import numpy as np
import pandas as pd
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import MinMaxScaler
import os
from config import SCALER_FEATURES

def clean_missing_fill(df):
    """
    Handle missing values: for numeric columns use median, forward/backfill for time series if needed.
    """
    num_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    # median imputation
    imputer = SimpleImputer(strategy="median")
    df[num_cols] = imputer.fit_transform(df[num_cols])
    # for any remaining NaNs (rare), forward fill
    df = df.fillna(method="ffill").fillna(method="bfill")
    return df

def remove_outliers_iqr(df, cols, k=1.5):
    """
    Remove extreme outliers based on IQR for specified cols.
    (We won't drop rows — we clip.)
    """
    df = df.copy()
    for col in cols:
        Q1 = df[col].quantile(0.25)
        Q3 = df[col].quantile(0.75)
        IQR = Q3 - Q1
        lower = Q1 - k * IQR
        upper = Q3 + k * IQR
        df[col] = df[col].clip(lower, upper)
    return df

def scale_features(df, feature_cols):
    """
    MinMaxScaler on selected features, returns scaler and scaled df
    """
    scaler = MinMaxScaler()
    df_scaled = df.copy()
    df_scaled[feature_cols] = scaler.fit_transform(df[feature_cols])
    return df_scaled, scaler

if __name__ == "__main__":
    from data_loader import load_data
    df = load_data()
    df = clean_missing_fill(df)
    print("After cleaning:", df.head())
