# train.py
import os
import numpy as np
import pandas as pd
from data_loader import load_data
from preprocess import clean_missing_fill, remove_outliers_iqr, scale_features
from feature_engineer import generate_all_features
from utils import train_test_split_time_series, create_lstm_sequences
from models import build_lstm, train_lstm, train_random_forest, save_sklearn_model
from config import SCALER_FEATURES, TARGET_COLUMN, LOOKBACK, EPOCHS, BATCH_SIZE, SAVED_MODEL_PATH, MODEL_DIR

os.makedirs(MODEL_DIR, exist_ok=True)

def main():
    print("Loading data...")
    df = load_data()
    print("Cleaning and feature engineering...")
    df = clean_missing_fill(df)
    df = remove_outliers_iqr(df, cols=["Open","High","Low","Close","Volume"] )
    df = generate_all_features(df)

    # Ensure target exists
    if TARGET_COLUMN not in df.columns:
        raise ValueError(f"Target column '{TARGET_COLUMN}' not found after feature engineering.")

    # Scale features (we'll drop Date before scaling)
    feature_cols = SCALER_FEATURES + [c for c in df.columns if c.startswith("MA_") or c in ["Volatility","Pct_Volatility","Return","Liquidity_lag1"]]
    feature_cols = [c for c in feature_cols if c in df.columns]
    df_scaled, scaler = scale_features(df, feature_cols)

    # Train-test split (time-based)
    train, test = train_test_split_time_series(df_scaled, TARGET_COLUMN)
    # Prepare LSTM sequences
    X_train, y_train = create_lstm_sequences(train[feature_cols].values, train[TARGET_COLUMN].values, lookback=LOOKBACK)
    X_test, y_test = create_lstm_sequences(test[feature_cols].values, test[TARGET_COLUMN].values, lookback=LOOKBACK)

    # Train LSTM
    print("Building LSTM...")
    lstm = build_lstm(input_shape=(X_train.shape[1], X_train.shape[2]), neurons=64, dropout=0.2)
    print("Training LSTM...")
    history = train_lstm(lstm, X_train, y_train, X_test, y_test, saved_path=SAVED_MODEL_PATH, epochs=EPOCHS, batch_size=BATCH_SIZE)
    print("LSTM training finished. Model saved to:", SAVED_MODEL_PATH)

    # Train RandomForest baseline (use last row features flattened)
    # Flatten sequences or use aggregated features for RF. We'll use rolling aggregates: last available features per day.
    print("Training RandomForest baseline (on non-sequence features)...")
    # Use the same feature columns but without sequences: use rows aligned to y (drop lookback rows)
    rf_train_X = train[feature_cols].values[LOOKBACK:]
    rf_train_y = train[TARGET_COLUMN].values[LOOKBACK:]
    rf_test_X = test[feature_cols].values[LOOKBACK:]
    rf_test_y = test[TARGET_COLUMN].values[LOOKBACK:]

    rf = train_random_forest(rf_train_X, rf_train_y, n_estimators=200)
    rf_path = f"{MODEL_DIR}/rf_model.joblib"
    save_sklearn_model(rf, rf_path)
    print("RandomForest saved to:", rf_path)

    # Save the scaler for later use
    import joblib
    joblib.dump(scaler, f"{MODEL_DIR}/scaler.joblib")
    print("Scaler saved.")

if __name__ == "__main__":
    main()
