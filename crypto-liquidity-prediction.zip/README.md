# Cryptocurrency Liquidity Prediction for Market Stability

## Overview
Predict cryptocurrency liquidity using historical price & volume data. Model outputs a liquidity estimate (proxy) to detect possible liquidity crises.

## Structure
- `data/crypto_data.csv` — put your CSV here
- `src/` — source code (loader, preprocess, training, evaluation, app)
- `models/` — saved models & scalers after training

## Requirements
Python 3.8+, see `requirements.txt`

## Run
1. Create venv and install:
   ```bash
   pip install -r requirements.txt
   ```
2. Place dataset at `data/crypto_data.csv`.
3. Train:
   ```bash
   python src/train.py
   ```
4. Evaluate:
   ```bash
   python src/evaluate.py
   ```
5. Run Streamlit app:
   ```bash
   streamlit run src/app_streamlit.py
   ```

## Notes
- The project uses a simple liquidity proxy `Liquidity = Volume / MarketCap`. If MarketCap missing, `Volume` is used and scaling helps.
- LSTM uses sliding window (LOOKBACK) to capture time patterns. RandomForest used as baseline.
- Tune hyperparameters (neurons, epochs, lookback) in `src/models.py` and `src/train.py`.
