Place your CSV file named 'crypto_data.csv' in this folder. Expected columns: Date, Open, High, Low, Close, Volume, MarketCap (MarketCap optional).
